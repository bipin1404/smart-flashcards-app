const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret_change_me';

function authenticate(req, res, next) {
  const auth = req.headers.authorization || '';
  const m = auth.match(/^Bearer\s+(.*)$/i);
  if (!m) return res.status(401).json({ message: 'Authorization header missing or invalid' });
  const token = m[1];

  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = {
      userId: payload.userId,
      student_id: payload.student_id,
      role: payload.role
    };
    return next();
  } catch (err) {
    console.error('JWT error', err);
    return res.status(401).json({ message: 'Invalid or expired token' });
  }
}

module.exports = authenticate;
