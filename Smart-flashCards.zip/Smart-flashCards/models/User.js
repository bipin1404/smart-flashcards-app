const mongoose = require('mongoose');
const bcrypt = require('bcrypt');

const SALT_ROUNDS = 12;

const UserSchema = new mongoose.Schema({
  student_id: { type: String, required: true, unique: true, index: true },
  email: { type: String, required: true, unique: true, lowercase: true, index: true },
  passwordHash: { type: String, required: true },
  displayName: { type: String },
  role: { type: String, enum: ['student','admin'], default: 'student' },
  created_at: { type: Date, default: Date.now }
});

// instance method
UserSchema.methods.verifyPassword = async function(password) {
  return bcrypt.compare(password, this.passwordHash);
};

// static helper
UserSchema.statics.createUser = async function({ student_id, email, password, displayName }) {
  const hash = await bcrypt.hash(password, SALT_ROUNDS);
  const u = new this({ student_id, email, passwordHash: hash, displayName });
  return u.save();
};

module.exports = mongoose.model('User', UserSchema);
