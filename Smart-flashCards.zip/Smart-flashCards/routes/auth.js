const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const User = require('../models/User');

const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret_change_me';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '1h';

/**
 * @openapi
 * /auth/register:
 *   post:
 *     summary: Register a new user (student)
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - student_id
 *               - email
 *               - password
 *             properties:
 *               student_id:
 *                 type: string
 *               email:
 *                 type: string
 *               password:
 *                 type: string
 *               displayName:
 *                 type: string
 *     responses:
 *       201:
 *         description: user created
 */
router.post('/auth/register', async (req, res) => {
  try {
    const { student_id, email, password, displayName } = req.body;
    if (!student_id || !email || !password) {
      return res.status(400).json({ message: 'student_id, email and password are required' });
    }

    const exists = await User.findOne({ $or: [{ student_id }, { email }] }).lean().exec();
    if (exists) {
      return res.status(409).json({ message: 'User with that student_id or email already exists' });
    }

    const user = await User.createUser({ student_id, email, password, displayName });
    return res.status(201).json({ message: 'User created', student_id: user.student_id, email: user.email });
  } catch (err) {
    console.error('Register error', err);
    return res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @openapi
 * /auth/login:
 *   post:
 *     summary: Login and get JWT token
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - email
 *               - password
 *             properties:
 *               email:
 *                 type: string
 *               password:
 *                 type: string
 *     responses:
 *       200:
 *         description: Returns access token
 */
router.post('/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ message: 'email and password required' });

    const user = await User.findOne({ email }).exec();
    if (!user) return res.status(401).json({ message: 'Invalid credentials' });

    const ok = await user.verifyPassword(password);
    if (!ok) return res.status(401).json({ message: 'Invalid credentials' });

    const payload = { userId: user._id.toString(), student_id: user.student_id, role: user.role };
    const token = jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });

    return res.json({ accessToken: token, tokenType: 'Bearer', expiresIn: JWT_EXPIRES_IN, student_id: user.student_id });
  } catch (err) {
    console.error('Login error', err);
    return res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
