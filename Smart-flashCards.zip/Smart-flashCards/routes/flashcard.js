const express = require('express');
const router = express.Router();
const Flashcard = require('../models/Flashcard');
const { detectSubject } = require('../classifier');
const redis = require('../lib/redisClient');
const authenticate = require('../middleware/authenticate');

/**
 * @openapi
 * /flashcard:
 *   post:
 *     security:
 *       - bearerAuth: []
 *     summary: Add a flashcard for the authenticated student (subject inferred)
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - question
 *               - answer
 *             properties:
 *               question:
 *                 type: string
 *               answer:
 *                 type: string
 *     responses:
 *       201:
 *         description: Flashcard added
 */
router.post('/flashcard', authenticate, async (req, res) => {
  try {
    // Use student_id from token — do NOT trust client-sent student_id
    const student_id = req.user.student_id;
    const { question, answer } = req.body;
    if (!question || !answer) {
      return res.status(400).json({ message: 'question and answer are required' });
    }
    const subject = detectSubject(question);
    const f = new Flashcard({ student_id, question, answer, subject });
    await f.save();

    // Invalidate related caches for this student
    if (redis) {
      try {
        const pattern = `get-subject:${student_id}:*`;
        const stream = redis.scanStream({ match: pattern, count: 100 });
        stream.on('data', (keys) => {
          if (keys.length) {
            redis.del(...keys).catch(err => console.error('Error deleting cache keys', err));
          }
        });
      } catch (err) {
        console.error('Cache invalidation error', err);
      }
    }

    return res.status(201).json({ message: 'Flashcard added successfully', subject });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error' });
  }
});

/**
 * @openapi
 * /get-subject:
 *   get:
 *     security:
 *       - bearerAuth: []
 *     summary: Get mixed flashcards by subject for the authenticated student
 *     parameters:
 *       - in: query
 *         name: limit
 *         required: false
 *         schema:
 *           type: integer
 *           default: 10
 *     responses:
 *       200:
 *         description: Array of flashcards
 */
router.get('/get-subject', authenticate, async (req, res) => {
  try {
    // Use student_id from token — do NOT trust client-sent student_id
    const student_id = req.user.student_id;
    const limit = Math.max(1, Math.min(100, parseInt(req.query.limit || '10')));

    const cacheKey = `get-subject:${student_id}:limit:${limit}`;

    // Try cache
    let cached = null;
    if (redis) {
      try {
        cached = await redis.get(cacheKey);
      } catch (e) {
        console.error('Redis GET failed, continuing without cache', e);
        cached = null;
      }
    }
    if (cached) {
      return res.json(JSON.parse(cached));
    }

    // Fetch from DB
    const cards = await Flashcard.find({ student_id }).lean().exec();
    if (!cards || cards.length === 0) return res.json([]);

    // Group by subject
    const bySubject = {};
    for (const c of cards) {
      bySubject[c.subject] = bySubject[c.subject] || [];
      bySubject[c.subject].push(c);
    }

    // Shuffle helper
    function shuffleArray(arr) {
      for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
      }
    }

    for (const subj in bySubject) shuffleArray(bySubject[subj]);

    // Round-robin pick to maximize subject diversity
    const subjects = Object.keys(bySubject);
    const result = [];
    let idx = 0;
    while (result.length < limit) {
      let addedThisRound = false;
      for (let s = 0; s < subjects.length && result.length < limit; s++) {
        const subj = subjects[(idx + s) % subjects.length];
        const bucket = bySubject[subj];
        if (bucket && bucket.length > 0) {
          const card = bucket.shift();
          result.push({ question: card.question, answer: card.answer, subject: card.subject });
          addedThisRound = true;
        }
      }
      if (!addedThisRound) break;
      idx++;
    }

    // Final shuffle
    shuffleArray(result);

    // Cache result conservatively
    if (redis) {
      try {
        const TTL_SECONDS = 60;
        await redis.set(cacheKey, JSON.stringify(result.slice(0, limit)), 'EX', TTL_SECONDS);
      } catch (e) {
        console.error('Redis SET failed', e);
      }
    }

    return res.json(result.slice(0, limit));
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
