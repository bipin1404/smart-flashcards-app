require('dotenv').config();
const mongoose = require('mongoose');
const Flashcard = require('./models/Flashcard');
const User = require('./models/User');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/flashcardsdb';

async function run() {
  await mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });
  console.log('Connected to Mongo for seeding');

  await Flashcard.deleteMany({});
  await User.deleteMany({});

  // Create a sample user
  const sampleUser = await User.createUser({
    student_id: 'stu001',
    email: 'stu001@example.com',
    password: 'Password123!', // dev-only
    displayName: 'Student One'
  });

  const data = [
    { student_id: sampleUser.student_id, question: "What is Newton's Second Law?", answer: "Force equals mass times acceleration", subject: "Physics" },
    { student_id: sampleUser.student_id, question: "What is photosynthesis?", answer: "A process used by plants to convert light into energy", subject: "Biology" },
    { student_id: sampleUser.student_id, question: "Define molarity", answer: "Moles of solute per liter of solution", subject: "Chemistry" },
    { student_id: sampleUser.student_id, question: "Derivative of x^2", answer: "2x", subject: "Mathematics" },
    { student_id: sampleUser.student_id, question: "What is an algorithm?", answer: "A step-by-step procedure for solving a problem", subject: "Computer Science" }
  ];

  await Flashcard.insertMany(data);
  console.log('Seeded flashcards and user');
  mongoose.disconnect();
}

run().catch(err => {
  console.error(err);
  process.exit(1);
});
