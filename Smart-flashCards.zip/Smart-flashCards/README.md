# 🧠 Smart Flashcards Backend API

A **smart flashcard management system** built with **Node.js, Express, MongoDB, Redis, and Docker**.  
It intelligently infers the *subject* of each flashcard (Physics, Biology, etc.) using text classification logic and serves mixed-subject flashcards efficiently.

✅ **Highlights:**
- Automatic subject inference (rule-based classification)
- JWT-based authentication (register/login)
- Caching with Redis
- Swagger API documentation
- MongoDB (Mongoose ORM)
- Dockerized microservices setup (Node + Redis + Mongo)
- Ready for AWS ECS / Docker Hub deployment

---

## 🏗️ Architecture Overview

Client (Postman/Frontend)
|
v
Express API (Node.js)
|
+--> MongoDB (store users & flashcards)
|
+--> Redis (cache GET /get-subject responses)


---

## 📁 Folder Structure

smart-flashcards/
├── Dockerfile
├── docker-compose.yml
├── server.js
├── package.json
├── .env.example
├── routes/
│ ├── auth.js
│ └── flashcards.js
├── models/
│ ├── Flashcard.js
│ └── User.js
├── lib/
│ └── redisClient.js
├── middleware/
│ └── authenticate.js
├── classifier.js
├── swagger.js
├── seed.js
└── README.md



---

## 🚀 Features

| Feature | Description |
|----------|--------------|
| 🧩 **Flashcards API** | Add, retrieve, and mix flashcards intelligently |
| 🤖 **Subject Detection** | Automatically detects subject based on question text |
| 🔒 **JWT Auth** | Secure register/login with password hashing |
| ⚡ **Redis Cache** | Caches student flashcard queries for faster response |
| 📜 **Swagger Docs** | Interactive API documentation at `/api-docs` |
| 🐳 **Docker Support** | Fully containerized stack (Mongo + Redis + App) |
| ☁️ **AWS Ready** | Compatible with ECS (Fargate) for production deployment |

---

## 🧰 Tech Stack

| Category | Technology |
|-----------|-------------|
| Backend Framework | Node.js (Express) |
| Database | MongoDB (Mongoose ORM) |
| Cache | Redis |
| Auth | JWT (JSON Web Tokens), bcrypt password hashing |
| API Docs | Swagger (swagger-ui-express, swagger-jsdoc) |
| Containerization | Docker & Docker Compose |
| Deployment | AWS ECS (Fargate) Ready |

---

## 🔐 Environment Variables

Copy `.env.example` → `.env` and configure:

```bash
PORT=3000
NODE_ENV=development

MONGO_URI=mongodb://mongo:27017/flashcardsdb
REDIS_HOST=redis
REDIS_PORT=6379

JWT_SECRET=dev_jwt_secret_change_me
JWT_EXPIRES_IN=1h

🧑‍💻 How to Run the Project
🧩 Option 1: Run Locally (without Docker)
Prerequisites:
Node.js ≥ 18
MongoDB installed & running locally on port 27017
Redis installed & running locally on port 6379
Steps:

# Clone repo
git clone https://github.com/<your-username>/smart-flashcards.git
cd smart-flashcards

# Install dependencies
npm install

# Copy env file
cp .env.example .env

# Start MongoDB & Redis locally (if not running)
mongod &
redis-server &

# Seed sample data
node seed.js

# Start API
npm start
📍 Visit:
API: http://localhost:3000
Swagger UI: http://localhost:3000/api-docs
Health Check: http://localhost:3000/health
🐳 Option 2: Run with Docker Compose (Recommended)
Prerequisites:
Docker Desktop / Docker Engine installed
Steps:
# Build and start containers
docker compose up --build

# (In new terminal) Seed sample data
docker compose exec app node seed.js

# Verify running containers
docker compose ps
📍 Access:
API: http://localhost:3000
Swagger UI: http://localhost:3000/api-docs
Health: http://localhost:3000/health
✅ Containers created:
Service	Description	Port
app	Express API	3000
mongo	MongoDB Database	27017
redis	Redis Cache	6379
To stop:
docker compose down
🔑 API Overview
Method	Endpoint	          Description	                         Auth
POST	 /auth/register	         Register new user	                    ❌
POST	 /auth/login	         Login and get JWT	                    ❌
POST	 /flashcard	             Add new flashcard (subject inferred)	✅
GET	/get-subject?limit=5	     Get mixed-subject flashcards	        ✅
GET	/health	Health check	                                            ❌


Example Login Response
{
  "accessToken": "eyJhbGciOiJIUzI1NiIs...",
  "tokenType": "Bearer",
  "expiresIn": "1h",
  "student_id": "stu001"
}
Use the accessToken as Bearer token in Authorization header.
🧪 Example Usage
Login:
curl -X POST http://localhost:3000/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"stu001@example.com","password":"Password123!"}'
Get Flashcards:
curl "http://localhost:3000/get-subject?limit=5" \
  -H "Authorization: Bearer <ACCESS_TOKEN>"
Add Flashcard:
curl -X POST http://localhost:3000/flashcard \
  -H "Authorization: Bearer <ACCESS_TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"question":"What is inertia?","answer":"Resistance to motion change"}'


🧱 Deployment (AWS ECS Quick Notes)

Build and push Docker image:
docker build -t smart-flashcards .
docker tag smart-flashcards <AWS_ACCOUNT>.dkr.ecr.<REGION>.amazonaws.com/smart-flashcards:latest
docker push <AWS_ACCOUNT>.dkr.ecr.<REGION>.amazonaws.com/smart-flashcards:latest
Use ECS Task Definition to deploy app container with environment variables from AWS Secrets Manager.
Connect via Application Load Balancer (HTTP:3000 → container port 3000).



---

# 📘 2. `docs/LOCAL_SETUP.md`
> Create a `docs/` folder and add this file inside it.

```markdown
# 🧩 Smart Flashcards – Local & Docker Setup Guide

This guide explains how to **run the Smart Flashcards backend** both locally (for dev) and via Docker Compose (for production-like setup).

---

## 🔧 Local Setup (Manual)

### Prerequisites
| Tool | Required Version |
|------|------------------|
| Node.js | 18+ |
| MongoDB | 6+ |
| Redis | 7+ |

### Steps

1. **Clone repository**
   ```bash
   git clone https://github.com/<your-username>/smart-flashcards.git
   cd smart-flashcards
Install dependencies
npm install
Setup environment variables
cp .env.example .env
Ensure MongoDB and Redis are running locally
mongod &
redis-server &
Seed the database
node seed.js
Start server
npm start
Test
Health: http://localhost:3000/health
Swagger: http://localhost:3000/api-docs
🐳 Docker Setup (Recommended)
Prerequisites
Docker installed
Docker Compose v2+
Steps
Build and start
docker compose up --build
Seed database
docker compose exec app node seed.js
Check containers
docker compose ps
Expected:
NAME       SERVICE   STATUS          PORTS
sf_app     app       running         0.0.0.0:3000->3000/tcp
sf_mongo   mongo     running         0.0.0.0:27017->27017/tcp
sf_redis   redis     running         0.0.0.0:6379->6379/tcp
Access
API: http://localhost:3000
Swagger Docs: http://localhost:3000/api-docs
Stop
docker compose down
🧪 Test API (after seeding)
Login
curl -X POST http://localhost:3000/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"stu001@example.com","password":"Password123!"}'
Get Flashcards
curl "http://localhost:3000/get-subject?limit=5" \
  -H "Authorization: Bearer <ACCESS_TOKEN>"